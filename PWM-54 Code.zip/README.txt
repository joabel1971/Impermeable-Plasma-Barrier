Permission is granted to copy, distribute and/or modify this document
under the terms of the GNU Free Documentation License, Version 1.3
or any later version published by the Free Software Foundation;
with no Invariant Sections, no Front-Cover Texts, and no Back-Cover
Texts.

----------------------------------------------------------------------
Impermeable Plasma Barrier (Force-Field) Experimental Testbed
----------------------------------------------------------------------

This is an Alpha release of the design & signaling code - for building an Impermeable Plasma Barrier Testbed and associated technologies.
This package is meant for (but not limited to) the testing of:

a. EM Superpositioned Impermeable Plasma Barriers
b. Tubular Linear Induction Motors
c. Water Electrolysis generators
d. Breathable, Isolated environments - for medical & pandemic isolation research.
e. Cubits (Onion-shaped 3d memory cells)
f. Generation of AC Power
g. Powering AC motors
h. AquaFuel (BINGO Fuel)
i. Desalianation of Water
j. Pollution and radioactive cleanup of water
k. Autonomous Hoverboards

'' =================================================================================================
''
''   File.......  ja_PWM_54.spin2 - Version 1.00 Alpha (09/29/2020)

''   Description. This software is a menu-based, 54 channel PWM (Pulse Width Modulator).
''                It is used with a Propeller 2 microcontroller (or potentially any P2 emulator).
''                The included serial-interface and String conversion routines were written by others.
''
''                This software creates 9 sets of 6 square-wave frequencies (1/4 wave to each other) meant for 		
                  Nicola Tesla experiments - including Plasma Barriers, Power and Water Electrolysis projects.
''                Each frequency is phase & duty cycle adjustable.
''                Square waves can be converted to sine-waves but require a cog for each channel.

''                Frequency ranges are from 1 Hz to 80,000,000 Hz in increments of 1 Hz (rounding of square-waves 			
                  start at about 25,000,000 Hz and are functionally sine-waves at 80,000,000 Hz).
''                The Duty-cycle for each frequency can be adjusted from 0-100% in increments of 1 percent.
''                Individual Phasing is adjustable from 0-360 degrees - in increments of 1 degree.

''                Known issues:  Phase errors between 1/4-wave frequencies become noticeable above 4 Khz.
''                               Rounding errors cause unwanted sweeping within certain frequency ranges.
''                               Many functional frequencies are not tested yet.
''                               Multiple Cogs have not been implemented yet, which will potentially allow multiple
     				 clock frequencies to run simultaneously - incsreasing overall working frequency 				ranges.

''                Tested (non-sweeping) lowest frequencies for _clkfreq = 100,000,000 Hz: 1, 2, 3, 4, 6, 8, 12, 25,
			30, 50, 100, 150, 200, 300, 400, 500, 800, 1600, 3200 Hz
''                Tested (non-sweeping) lowest frequencies for _clkfreq = 250,000,000 Hz: 1, 2, 3, 4, 5, 6, 10, 12, 		
			15, 17, 18, 20, 30, 60, 200, 240, 400, 800, 960, 3840, 15360, 61440 Hz
''                Tested (non-sweeping) lowest frequencies for _clkfreq = 333,333,333 Hz: 1, 2, 3, 4, 5, 6, 8, 10, 		
			13, 16, 20, 24, 40, 50, 80, 100, 300, 500, 800 Hz, 78125 Hz.

''   Purpose....  To signal superpositioned, multilayer, interleaved Coils (patent #512,340) - meant to generate 		
		  Water Electrolysis, 60 Hz power, Tubular Linear Induction Motors, and Impermeable Plasma 		  	Barriers.
''
''                A Plasma Barrier design (PDF document) is included within the zipfile & meant to be distribuated 		
		  with this source code.
''
''                The design for Impermeable Plasma Barriers can be tested for multiple peaceful uses - including 		
		  the creation of environments, cubit memory cells, BINGO (Aqua) Fuel, audio speakers, and 		
		  potentially a space-survival shell (shield) to protect life,
''                and allow warp drive.
''                No more than 24-volts of DC is needed for initial testing (maximum current for 30 AWG wire - per 		
		  layer - is about 1 amp).
''                Therefore, only 24 watts per wire-layer is needed.

''   Author.....  Jon Abel
''                Copyright (c) 2020 Jon Abel (09/28/2020)
''                -- see below for terms of use
''   E-mail.....  joabel1971@yahoo.com
''   Started....  August 14, 2020
''   Updated....  November. 20th, 2020
''   Other Credits.  Listed authors & and their licenses are shown within the serial-interface code, and Number-		
			to-String Conversion routines.

''   Latest updates:

''   Nov. 20th, 2020 - Sweep function implemented, which allows a repeating loop of incremented frequencies on a 		
			specific channel for a certain delay.

'' =================================================================================================

''    ***  GPL License ***
''    This program is free software: you can redistribute it and/or modify
''    it under the terms of the GNU General Public License as published by
''    the Free Software Foundation, either version 3 of the License, or
''    (at your option) any later version.

''    This program is distributed in the hope that it will be useful,
''    but WITHOUT ANY WARRANTY; without even the implied warranty of
''    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
''    GNU General Public License for more details.

''    You should have received a copy of the GNU General Public License
''    along with this program.  If not, see <https://www.gnu.org/licenses/>.







